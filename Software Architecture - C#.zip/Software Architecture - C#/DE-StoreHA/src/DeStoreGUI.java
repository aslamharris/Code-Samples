import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;

public class DeStoreGUI {
    private JButton PriceControlButton;
    private JPanel panel1;
    private JButton loyaltyCardButton;
    private JButton inventoryControlButton;
    private JButton financeApprovalButton;
    private JButton reportsAndAnalysisButton;
    private JButton shippingCostsButton;


    public DeStoreGUI() {
        PriceControlButton.addActionListener(new ActionListener() {
            @Override
            // carry out action when button clicked
            public void actionPerformed(ActionEvent actionEvent) {
                Form NewProductForm = new Form();
                NewProductForm.NewScreen();
            }
        });

        inventoryControlButton.addActionListener(new ActionListener() {
            @Override
            // carry out action when button clicked
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    // Load the driver
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    // First we need to establish a connection to the database
                    Connection conn = DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/DE-Store", "root", "root1234");

                    System.out.println("Connected to database");

                    // Next we create a statement to access the database

                    Statement statement = conn.createStatement();
                    // Now create a simple query to get all records from the database

                    ResultSet rs = statement.executeQuery("SELECT * FROM list");

                    // It creates and displays the table
                    JTable table = new JTable(buildTableModel(rs));
                    table.setPreferredScrollableViewportSize(table.getPreferredSize());
                    table.setFillsViewportHeight(true);


                    // Closes the Connection

                    JOptionPane.showMessageDialog(null, new JScrollPane(table));

                }
                catch (ClassNotFoundException cnf)
                {
                    System.err.println("Could not load driver");
                    System.err.println(cnf.getMessage());
                    System.exit(-1);
                }
                catch (SQLException sqe)
                {
                    System.out.println("Error performing SQL Query");
                    System.out.println(sqe.getMessage());
                    System.exit(-1);
                }
            }
        });

        loyaltyCardButton.addActionListener(new ActionListener() {
            @Override
            // carry out action when button clicked
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    // Load the driver
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    // First we need to establish a connection to the database
                    Connection conn = DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/DE-Store", "root", "root1234");

                    System.out.println("Connected to database");

                    // Next we create a statement to access the database

                    Statement statement = conn.createStatement();
                    // Now create a simple query to get all records from the database

                    ResultSet rs = statement.executeQuery("SELECT * FROM list where LoyaltyCard = \"yes\"");

                    // It creates and displays the table
                    JTable table = new JTable(buildTableModel(rs));
                    table.setPreferredScrollableViewportSize(table.getPreferredSize());
                    table.setFillsViewportHeight(true);

                    // Closes the Connection

                    JOptionPane.showMessageDialog(null, new JScrollPane(table));

                }
                catch (ClassNotFoundException cnf)
                {
                    System.err.println("Could not load driver");
                    System.err.println(cnf.getMessage());
                    System.exit(-1);
                }
                catch (SQLException sqe)
                {
                    System.out.println("Error performing SQL Query");
                    System.out.println(sqe.getMessage());
                    System.exit(-1);
                }
            }
        });

        financeApprovalButton.addActionListener(new ActionListener() {
            @Override
            // carry out action when button clicked
            public void actionPerformed(ActionEvent actionEvent) {
                JOptionPane.showMessageDialog(null,"Connecting to Finance Portal...");

                try {
                    // Load the driver
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    // First we need to establish a connection to the database
                    Connection conn = DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/DE-Store", "root", "root1234");

                    System.out.println("Connected to database");

                    // Next we create a statement to access the database

                    Statement statement = conn.createStatement();
                    // Now create a simple query to get all records from the database

                    ResultSet rs = statement.executeQuery("SELECT * FROM list where financeAllowed = \"yes\"");

                    // It creates and displays the table
                    JTable table = new JTable(buildTableModel(rs));
                    table.setPreferredScrollableViewportSize(table.getPreferredSize());
                    table.setFillsViewportHeight(true);

                    // Closes the Connection

                    JOptionPane.showMessageDialog(null, new JScrollPane(table));

                }
                catch (ClassNotFoundException cnf)
                {
                    System.err.println("Could not load driver");
                    System.err.println(cnf.getMessage());
                    System.exit(-1);
                }
                catch (SQLException sqe)
                {
                    System.out.println("Error performing SQL Query");
                    System.out.println(sqe.getMessage());
                    System.exit(-1);
                }

            }
        });

        reportsAndAnalysisButton.addActionListener(new ActionListener() {
            @Override
            // carry out action when button clicked
            public void actionPerformed(ActionEvent actionEvent) {
                Reports r = new Reports();
                r.ProductForm();
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }

    public static DefaultTableModel buildTableModel(ResultSet rs)
            throws SQLException {

        ResultSetMetaData metaData = rs.getMetaData();

        // names of columns
        Vector<String> columnNames = new Vector<String>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        // data of the table
        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<Object>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }

        return new DefaultTableModel(data, columnNames);

    }

    public static void openMenu() {
        // displaying the frame
        JFrame frame = new JFrame("De-Store Coursework HA");
        frame.setContentPane(new DeStoreGUI().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
    }
}
