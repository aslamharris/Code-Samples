import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login {
    private JTextField textField1;
    private JButton loginButton;
    private JTextField textField2;
    private JPanel loginPanel;

    public Login() {

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = textField1.getText();
                String password = textField2.getText();

                if ((username.matches("admin")) && (password.matches("admin")))
                {
                    System.out.println("Login successful");
                    DeStoreGUI r = new DeStoreGUI();
                    r.openMenu();
                }
                else {
                    System.out.println("invalid login details");
                    JOptionPane.showMessageDialog(null,"Incorrect login details");
                }


            }
        });
    }

    public static void main(String[] args) {
        // displaying the frame
        JFrame frame = new JFrame("De-Store Coursework HA");
        frame.setContentPane(new Login().loginPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
    }
}
