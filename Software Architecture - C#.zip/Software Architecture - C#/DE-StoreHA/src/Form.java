import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Form {
    private JPanel PCFormPanel;
    private JTextField ProductNameText;
    private JTextField BranchNameText;
    private JTextField OffersText;
    private JTextField LoyaltyCardText;
    private JTextField StockNumberText;
    private JButton SubmitButton;
    private JFormattedTextField PriceText;
    private JTextField IdentifierTextField;
    private JLabel Identifier;
    private JTextField FinanceField;

    public Form() {
        SubmitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try {
                    // Load the driver
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    // First we need to establish a connection to the database
                    Connection conn = DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/DE-Store", "root", "root1234");

                    System.out.println("Connected to database");

                    // Set up keyboard input
                    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
                    // Prompt for new Student details
                    String identifier = IdentifierTextField.getText();
                    System.out.println(identifier);

                    String productName = ProductNameText.getText();
                    System.out.println(productName);

                    String branchName = BranchNameText.getText();
                    System.out.println(branchName);

                    String price = PriceText.getText();
                    System.out.println(price);

                    String offer = OffersText.getText();
                    System.out.println(offer);

                    String loyaltyCard = LoyaltyCardText.getText();
                    System.out.println(loyaltyCard);

                    String financeApproved = FinanceField.getText();
                    System.out.println(financeApproved);

                    String stock = StockNumberText.getText();
                    System.out.println(stock);

                    // Create a new SQL statement
                    Statement statement = conn.createStatement();
                    // Build the INSERT statement
                    String update = "INSERT INTO list (Identifier, ProductName, Branch, Price, Offers, LoyaltyCard, FinanceAllowed, Stock) " +
                            "VALUES ('" + identifier + "','" + productName + "', '" + branchName + "', '" + price + "','"+ offer + "', '" + loyaltyCard + "', '" + financeApproved + "', '" + stock + "')";
                    // Execute the statement
                    statement.executeUpdate(update);
                    // Release resources held by the statement
                    statement.close();
                    // Release resources held by the connection.  This also ensures that the INSERT completes
                    conn.close();
                    System.out.println("Update successful");

                    JOptionPane.showMessageDialog(null,"New product has been added to database");

                    int i = Integer.parseInt(stock);

                    if(i < 2)
                    {
                        System.out.println("Stock level less than 2");
                        final JFrame parent = new JFrame();
                        JButton button = new JButton();

                        button.setText("Stock level less than 2 " +
                                "Click to order more stock from central inventory system!");
                        parent.add(button);
                        parent.pack();
                        parent.setVisible(true);

                        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                        parent.setLocation(dim.width/2-parent.getSize().width/2, dim.height/2-parent.getSize().height/2);

                        button.addActionListener(new java.awt.event.ActionListener() {
                            @Override
                            public void actionPerformed(java.awt.event.ActionEvent evt) {
                                JOptionPane.showMessageDialog(parent,"Item Low in Stock - email and mobile message sent to manager");
                            }
                        });
                    }

                    IdentifierTextField.setText("");
                    ProductNameText.setText("");
                    BranchNameText.setText("");
                    PriceText.setText("");
                    OffersText.setText("");
                    LoyaltyCardText.setText("");
                    FinanceField.setText("");
                    StockNumberText.setText("");

                }

                catch(ClassNotFoundException ex){
                    ex.printStackTrace();
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
            }
        });
    }

    public static void NewScreen() {
        JFrame frame = new JFrame("De-Store Coursework HA");
        frame.setContentPane(new Form().PCFormPanel);
        frame.pack();
        frame.setVisible(true);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
    }
}
