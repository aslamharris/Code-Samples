import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class Reports {

    private JButton glasgowReport;
    private JButton EdinburghReport;
    private JPanel Report;
    private JButton RestofReports;

    public Reports() {

        EdinburghReport.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    // Load the driver
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    // First we need to establish a connection to the database
                    Connection conn = DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/DE-Store", "root", "root1234");

                    System.out.println("Connected to database");

                    // Next we create a statement to access the database

                    Statement statement = conn.createStatement();
                    // Now create a simple query to get all records from the database

                    ResultSet rs = statement.executeQuery("SELECT productName, stock * price FROM list where Branch = \"Edinburgh\";");

                    // It creates and displays the table
                    JTable table = new JTable(buildTableModel(rs));
                    table.setPreferredScrollableViewportSize(table.getPreferredSize());
                    table.setFillsViewportHeight(true);


                    // Closes the Connection

                    JOptionPane.showMessageDialog(null, new JScrollPane(table));

                }
                catch (ClassNotFoundException cnf)
                {
                    System.err.println("Could not load driver");
                    System.err.println(cnf.getMessage());
                    System.exit(-1);
                }
                catch (SQLException sqe)
                {
                    System.out.println("Error performing SQL Query");
                    System.out.println(sqe.getMessage());
                    System.exit(-1);
                }

            }
        });

        glasgowReport.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Load the driver
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    // First we need to establish a connection to the database
                    Connection conn = DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/DE-Store", "root", "root1234");

                    System.out.println("Connected to database");

                    // Next we create a statement to access the database

                    Statement statement = conn.createStatement();
                    // Now create a simple query to get all records from the database

                    ResultSet rs = statement.executeQuery("SELECT productName, stock * price FROM list where Branch = \"Glasgow\";");

                    // It creates and displays the table
                    JTable table = new JTable(buildTableModel(rs));
                    table.setPreferredScrollableViewportSize(table.getPreferredSize());
                    table.setFillsViewportHeight(true);


                    // Closes the Connection

                    JOptionPane.showMessageDialog(null, new JScrollPane(table));

                }
                catch (ClassNotFoundException cnf)
                {
                    System.err.println("Could not load driver");
                    System.err.println(cnf.getMessage());
                    System.exit(-1);
                }
                catch (SQLException sqe)
                {
                    System.out.println("Error performing SQL Query");
                    System.out.println(sqe.getMessage());
                    System.exit(-1);
                }

            }
        });
        RestofReports.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    // Load the driver
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    // First we need to establish a connection to the database
                    Connection conn = DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/DE-Store", "root", "root1234");

                    System.out.println("Connected to database");

                    // Next we create a statement to access the database

                    Statement statement = conn.createStatement();
                    // Now create a simple query to get all records from the database

                    ResultSet rs = statement.executeQuery("SELECT productName,  stock * price FROM list where Branch != \"Edinburgh\" or \"Glasgow\";\n");

                    // It creates and displays the table
                    JTable table = new JTable(buildTableModel(rs));
                    table.setPreferredScrollableViewportSize(table.getPreferredSize());
                    table.setFillsViewportHeight(true);

                    // Closes the Connection

                    JOptionPane.showMessageDialog(null, new JScrollPane(table));

                }
                catch (ClassNotFoundException cnf)
                {
                    System.err.println("Could not load driver");
                    System.err.println(cnf.getMessage());
                    System.exit(-1);
                }
                catch (SQLException sqe)
                {
                    System.out.println("Error performing SQL Query");
                    System.out.println(sqe.getMessage());
                    System.exit(-1);
                }


            }
        });
    }

    public static void ProductForm() {
        JFrame frame = new JFrame("De-Store Coursework HA");
        frame.setContentPane(new Reports().Report);
        // frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
    }

    public static DefaultTableModel buildTableModel(ResultSet rs)
            throws SQLException {

        ResultSetMetaData metaData = rs.getMetaData();

        // names of columns
        Vector<String> columnNames = new Vector<String>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        // data of the table
        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<Object>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }

        return new DefaultTableModel(data, columnNames);

    }
}
