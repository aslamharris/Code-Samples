package com.and.test;

import java.util.*;
import java.util.stream.Collectors;

public class Solution {

    /**
     * The following is the method where the solution shall be written
     */

    public static String solution(String input) throws NumberFormatException {

        // Ensure string is made up of numbers only
        String fixInput = input.replaceAll("[^0-9]", "");

        // Display error message if no number found
        if (fixInput.equals("")) {
            return "Input error - number not found";
        } else {
            // Set to store original list of rearranged numbers
            Set<String> rearrangedDigits = rearrangeDigits(fixInput);

            // Here we use a list to reverse the order if the set
            List<String> reverseOrder = new ArrayList(rearrangedDigits);

            // used to sort the elements present in the list
            Collections.sort(reverseOrder, Collections.reverseOrder());

            // store the reversed list into a string so that the answer value can be returned and displayed
            String list = "";

            for (String s : reverseOrder) {
                    list += s + " ";
            }
            return list;
        }
    }

        // This function carries out the rearranging of the number to find all combinations.
        public static Set<String> rearrangeDigits(String set) {

            // Tree set to get rid of duplicate items
            Set<String> createList = new TreeSet<String>();

            if (set.length() == 1) {
                createList.add(set);
            } else {
                for (int i = 0; i < set.length(); i++) {

                    String last = set.substring(i + 1);
                    String number = set.substring(0, i);

                    String left = number + last;

                    //Find the rest of the combinations using the remaining values
                    for (String findCombinations : rearrangeDigits(left)) {
                        createList.add(set.charAt(i) + findCombinations);
                    }
                }
            }
            // return the answer to the solution method
            return createList;
        }

    public static void main(String args[]) {

        // send the value to be rearranged to the solution method and save the answer
        String answer = solution("A 3B2 C6D");

        // display the answer
        System.out.println("\nAnswer: " + answer);
    }
}
