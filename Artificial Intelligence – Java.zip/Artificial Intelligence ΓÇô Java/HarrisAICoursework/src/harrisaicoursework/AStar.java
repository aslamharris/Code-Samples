package harrisaicoursework;

import java.util.*;

/**
 *
 * @Author Harris Aslam
 * @Date:  02/11/18
 * 
 **/

// A Star class where the shortest path algorith is coded. 
// The shortest path should be found and returned to the main class
public class AStar 
{
    public List<Node> aStar(Node start, Node goal, int [][] matrix, int numberOfCaverns, List<Node> coordinates) 
    {
        // set of nodes that have been discovered but not yet evaluated
        Set<Node> open = new HashSet<>();
        // set of nodes that have been evaluated
        Set<Node> closed = new HashSet<>();

        // saves length of 
        double pathLength = 0;

        // the cost of going from start to start is zero
        start.gScore = 0;
        
        // for each node, the total cost of getting from the start node to the 
        // goal is by passing by that node. 
        // that value is partly known, partly heuristic.
        // for the first node, that value is completely heuristic.
        start.fScore = start.heuristic;
        start.heuristic = (int) estimateDistance(start, goal);

        // adds start node to the open set
        open.add(start);

        while(true) 
        {
            // sets current node to null
            Node current = null;

            // loops through open set and checks the nodes
            for (Node node : open) 
            {
                if (current == null || node.fScore < current.fScore) 
                {
                    current = node;
                }
            }
            
            // if the current node is equal to the goal node then 
            // the program will stop running
            if (current == goal) 
            {
                break;
            }
            
            // the current node should be removed from the open set 
            // and added to the closed set
            open.remove(current);
            closed.add(current);

            // uses the find neighbours class in node class to look around the 
            // nodes close to the current code that the program is on]
            // in a try and catch to prevent crashing if a null value occurs
            try 
            {
                current.setNeighbours(current.findNeighbours(matrix, numberOfCaverns, coordinates));
            }
            catch (java.lang.NullPointerException e)
            {
                   break;
            }

            // loops through current neighbours to find the best neighbour path
            for (Node neighbor : current.neighbours) 
            {
                if (neighbor == null)
                {
                    continue;
                }

                // the distance from start to a neighbor
                int tentative_g_score = (int) (current.gScore + estimateDistance(current, neighbor));

                if (tentative_g_score < neighbor.gScore) 
                {
                    open.remove(neighbor);
                    closed.remove(neighbor);
                }
                
                // if this if statement is true then this is not a better path 
                // so just keep going
                if(closed.contains(neighbor) && tentative_g_score >= neighbor.gScore) 
                {
                    continue;
                }
                
                // if this if statement is true then discover a new node
                if ((!open.contains(neighbor) || tentative_g_score < neighbor.gScore))
                {
                    // this path is the best until now
                    // record it by storing in open set
                    neighbor.gScore = tentative_g_score;
                    neighbor.fScore = neighbor.gScore + neighbor.heuristic;
                    neighbor.heuristic = (int) estimateDistance(neighbor, goal);
                    neighbor.parent = current;

                    open.add(neighbor);
                }
            }
        }

        // stores list of fastest path nodes 
        List<Node> nodes = new ArrayList<>();

        Node current = goal;

        while (current.parent != null)
        {
            // this equation is used to find the path and stores in pathLength variable
            pathLength += Math.sqrt(Math.pow((current.x - current.parent.x),2) + Math.pow((current.y - current.parent.y),2));
            
            // adds node to nodes list
            nodes.add(current);
            
            current = current.parent;
        }

        // this if statement adds the start node to the nodes list 
        // so that the first node is shown on the path
        if(nodes.size() > 0)
        {
            nodes.add(start);
        }

        // this if statement displays the path length and 
        // rounds the number up to 2 significant figures
        if(pathLength > 0)
        {
            System.out.printf("Path Length: %.2f", pathLength);
            System.out.println("\n");
        }

        return nodes;
    }

    // this function is the mathematical equation given to be used to 
    // find the distance between two paths
    public double estimateDistance(Node node1, Node node2) 
    {
        double distance = Math.sqrt(Math.pow((node2.x - node1.x),2) + Math.pow((node2.y - node1.y),2));
        return distance;
    }
}