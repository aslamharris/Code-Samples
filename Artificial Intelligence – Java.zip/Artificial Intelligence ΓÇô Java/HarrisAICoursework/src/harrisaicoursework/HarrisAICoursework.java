package harrisaicoursework;

import java.io.*;
import java.util.*;

/**
 *
 * @Author Harris Aslam
 * @Date:  02/11/18
 * 
 **/

// This program reads in a file and has to find the shortest path between all the nodes
// I have used the A Star path finding algorithm to try and find the shortest path
public class HarrisAICoursework 
{
    public static void main(String[] args) 
    {
        List<Integer> Map = new ArrayList<>();
        File cavFile = null;
        String filename = args[0];

        // this code allows file name to be tyoed in without having to add 
        // the full extension on to the name
        // file to be read in
        try
        {
            if(filename.contains(".cav"))
            {
                // if the file name contians .cav it accepts and uses it 
                cavFile = new File(args[0]);
            }
            else
            {
                // if filename does not include .cav it adds it on to the end 
                // and finds that file
                cavFile = new File(args[0]+".cav");
            }
        }
        catch(NullPointerException e)
        {
            System.out.println("File is null, please enter file name");
        }
        
        try
        {
            // this function reads in the cavern file and 
            // begins to add the numbers to a list called Map
            FileReader fr = new FileReader(cavFile);
            try (BufferedReader br = new BufferedReader(fr))
            {
                String input;

                while((input = br.readLine()) != null)
                { 
                    // breaks whole string into "tokens" / each number 
                    // split by the comma
                    StringTokenizer st = new StringTokenizer(input,",");

                    while(st.hasMoreTokens())
                    {
                        // adds number to Map list
                        Map.add(Integer.parseInt(st.nextToken()));
                    }
                }
            }
        }
        catch(IOException e)
        {
            System.out.println("File not found");
        }
        catch(NumberFormatException n)
        {
            System.out.println("This is not a number");
        }

        System.out.println("File Read: " + cavFile + "\n");

        // stores the number of caverns in the file
        int numberOfCaverns = Map.get(0);

        // displays the number of caverns in the file
        System.out.println("Number of caverns: " + numberOfCaverns + "\n");

        // stores the coordinates of each node
        List<Node> coordinates = new ArrayList<>();

        // this for loop creates the nodes by using the coordinates read in and 
        // using the node class
        for(int c = 1; c < numberOfCaverns*2; c += 2)
        {
            int x = Map.get(c); // finds and stores x value
            int y = Map.get(c+1); // finds and stores y value
            
            // sends coordinates to the node class to create node
            Node Node = new Node(x, y);
            // adds node to coordinates list
            coordinates.add(Node);
        }
        
        // this list stores the numbers needed to create the matrix
        List<Integer> matrixNumbers = new ArrayList<>();

        // this function will get the matrix numbers from the Map and 
        // add to the matrix list
        for(int num = (numberOfCaverns*2 + 1); num < Map.size(); num++)
        {
            matrixNumbers.add(Map.get(num));
        }

        // this 2d array stores the matrix
        int[][] matrix = new int [numberOfCaverns][numberOfCaverns];
        
        int random = 0;

        // this for loop builds the matrix 
        for (int[] m : matrix) 
        {
            for (int j = 0; j < m.length; j++) 
            {
                m[j] = matrixNumbers.get(random);
                random++;
            }
        }

        // this code runs the A Star class to find the fastest path
        AStar aStar = new AStar();
        List<Node> pathFinder = aStar.aStar(coordinates.get(0), coordinates.get(coordinates.size()-1), matrix, numberOfCaverns, coordinates);
        
        // reverses the path to show the first node at the beginning
        Collections.reverse(pathFinder);
        
        // creates a file called file.csn to save the path found
        File pathFound = null;
        
         if(filename.contains(".cav"))
        {
            pathFound = new File(filename.substring(0, filename.length()-3)+"csn");
        }
        else
        {
            pathFound = new File(filename.substring(0, filename.length())+".csn");
        }
        
                
            // this function will iterate try and create the file and 
            // write in the found path to that file
            try
            {
                FileWriter fw = new FileWriter(pathFound);
                BufferedWriter bw = new BufferedWriter(fw);
                
                if(pathFinder.isEmpty())
                {
                    System.out.println("No path found \n");
                    // writes path to file if path is 0
                    bw.write("0");
                }
                else
                {
                    // loop through the pathFinder to write
                    // the found path to the file
                    for(Node found : pathFinder)
                    {
                        int index = coordinates.indexOf(found);
                        // prints path out in output
                        System.out.print((index + 1) + " ");
                        // writes path to file
                        bw.write((index + 1) + " ");
                    }
                    System.out.println("\n");
                }
                bw.close();
            }
            catch(IOException e)
            {
                System.out.println("An I/O error has occured");
            }
            
            // displays the name of the file created
            System.out.println("File Created: " + pathFound + "\n" );
    }
}