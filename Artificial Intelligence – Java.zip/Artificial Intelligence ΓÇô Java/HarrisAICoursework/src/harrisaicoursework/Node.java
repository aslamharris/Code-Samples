package harrisaicoursework;

import java.util.*;

/**
 *
 * @Author Harris Aslam
 * @Date:  02/11/18
 * 
 **/

// Node class used to create the nodes from the coordinates 
// stored from the main class, also used to find the neighbours
public class Node 
{
    List<Node> neighbours = new ArrayList<>();
    Node parent;
    
    int x;
    int y;
    
    int fScore;
    int gScore;
    int heuristic;

    public Node(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    
    public List<Node> findNeighbours(int[][] m, int numberOfCaverns, List<Node> coordinates) 
    {
        // stores the matrix
        int[][] matrix = m;
        
        // stores number of caverns on the map
        int caverns = numberOfCaverns;

        // stores list of nodes
        List<Node> nodes = coordinates;

        // stores the column the current node is in
        int columnIndex = nodes.indexOf(this);

        // loops down specific column where current node is
        for(int rowIndex = 0; rowIndex < matrix.length; rowIndex++) 
        {
            // stores value of matrix either 1 or 0
            int value = matrix[rowIndex][columnIndex];
            
            if (value == 1) 
            {
                // stores the neighbour index in the full matrix
                int neighbourIndex = rowIndex * caverns + columnIndex;

                // converts it to the index of the nodes list
                neighbourIndex /= caverns;

                // stores the node and adds it to the list
                Node neighbour = nodes.get(neighbourIndex);
                neighbours.add(neighbour);
            }
        }
        return neighbours;
    }
    
    public void setNeighbours(List<Node> neighbours)
    {
        this.neighbours = neighbours;
    }
}