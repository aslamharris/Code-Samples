﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Newtonsoft.Json;

namespace CourseworkHA
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void btn_ReadNext_Click(object sender, RoutedEventArgs e)
        {
            readInFile();
        }

        // used to parse the tweet and SMS class data so that it can be written to JSON
        private class data
        {
            public string ID { get; set; }

            public string Body { get; set; }

            public string Sender { get; set; }

        }

        private class emailData
        {
            public string ID { get; set; }

            public string Body { get; set; }

            public string Subject { get; set; }

            public string Sender { get; set; }

            public string NoI { get; set; }

            public Boolean SIR { get; set; }
        }

        public void readInFile()
        {

            List<data> trending = new List<data>();

            List<string> ID = new List<string>();
            List<string> Sender = new List<string>();
            List<string> Body = new List<string>();


            var filePath = @"stTestHA.json";
            var jsonData = File.ReadAllText(filePath);
            var model = JsonConvert.DeserializeObject<List<data>>(jsonData);


            foreach (var item in model)
            {
                trending.Add(item);
            }

            foreach (var item in trending)
            {
                ID.Add(item.ID);

                if (item.ID.Contains("s"))
                {
                    Body.Add("Mobile: " + item.Sender + "\n" + "Body: " + item.Body);
                }
                else if (item.ID.Contains("t"))
                {
                    Body.Add("Twitter ID: " + item.Sender + "\n" + "Body: " + item.Body);
                }
            }

            foreach (var item in ID)
            {
                txt_ReadID.Text = item;
            }

            foreach (var item in Body)
            {
                txt_ReadBody.Text = item;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
                List<emailData> trending = new List<emailData>();

                List<string> ID = new List<string>();
                List<string> Body = new List<string>();

                var emailfilePath = @"emailTestHA.json";
                var emailjsonData = File.ReadAllText(emailfilePath);
                var emailmodel = JsonConvert.DeserializeObject<List<emailData>>(emailjsonData);

                foreach (var item in emailmodel)
                {
                    trending.Add(item);
                }

                foreach (var item in trending)
                {
                    ID.Add(item.ID);
                    if (item.SIR == true)
                    {
                        Body.Add("Sender: " + item.Sender + "\n" + "Subject: " + item.Subject + "\n" + "Nature of Incident: " + item.NoI + "\n" + "Body: " + item.Body);
                    }
                    else if(item.SIR == false)
                    {
                        Body.Add("Sender: " + item.Sender + "\n" + "Subject: " + item.Subject + "\n" + "Body: " + item.Body);
                    }
                }

                foreach (var item in ID)
                {
                    txt_ReadID.Text = item;
                }
                foreach (var item in Body)
                {
                    txt_ReadBody.Text = item;
                }
        }
    }
}
