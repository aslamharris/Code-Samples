﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;


namespace CourseworkHA
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // this code will run if their are no text files created
            // these are used for the purpose of storing information into relavant JSON files
            if (!File.Exists(@"messageIDs.txt"))
            {
                File.Create(@"messageIDs.txt");
            }
            if (!File.Exists(@"stTestHA.json"))
            {
                File.Create(@"stTestHA.json");
            }
            if (!File.Exists(@"emailTestHA.json"))
            {
                File.Create(@"emailTestHA.json");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // stores message ID's previoulsy used in JSON files.
            List<string> messageIDs = new List<string>();

            string[] message = null;
            bool id = true;
            // this stores ID entered by user
            string header = txt_Header.Text;
            header = header.ToUpper();

            // this try catch reads message ID's revously used to make sure the usre cannot use the same ID twice
            try
            {

                //reads in message ID file
                var readerID = new StreamReader(@"messageIDs.txt");

                // adds message ID's from file to list
                using (readerID)
                {
                    while ((!readerID.EndOfStream))
                    {
                        string trendingWord = readerID.ReadLine().ToString();
                        messageIDs.Add(trendingWord);
                    }
                }

                // splits message ID's and adds to string array
                foreach (String st in messageIDs)
                {
                    message = st.Split(',');
                }

                // if the message Id has already been used will display error message 
                // if not will allow progran to contiue running
                foreach (String st in message)
                {
                    var words = st.Split().Select(x => x.Trim());

                    if (words.Contains(header))
                    {
                        MessageBox.Show("Message header already used");
                        id = false;
                    }
                }

                // runs actual program
                if (id != false)
                {
                    // stores first character of the message ID which is used to determine which messenger class to run
                    string messageType = null;
                    //stores data after first character and makes sure it is only a 9 digit number 
                    string number = null;

                    try
                    {
                        // substring first character of the message ID 
                        messageType = header.Substring(0, 1);
                        // substring after first character of the message ID 
                        number = header.Substring(1, 9);
                    }
                    catch(ArgumentOutOfRangeException)
                    {
                        // will display if incorrect id is entered
                        Console.WriteLine("INPUT HEADER INCORRECT");
                    }

                    // runs is numbers only method to ensure only numbers have been entered after first charcter of ID
                    numbers n = new numbers();

                    // will run if the message type and message number is not empty 
                    if (messageType != null && number != null)
                    {
                        // will only run if the message tye is 's' so the SMS function will run and numbers variable only contains numbers
                        if (messageType == "S" && (n.IsDigitsOnly(number) == true))
                        {
                            Console.WriteLine("SMS function will now run \n");
                            // run SMS function
                            SMS();
                        }
                        // will only run if the message tye is 'e' so the Email function will run and numbers variable only contains numbers
                        else if (messageType == "E" && (n.IsDigitsOnly(number) == true))
                        {
                            Console.WriteLine("Email function will now run \n");
                            // run Email function
                            Email();
                        }
                        // will only run if the message tye is 't' so the Tweet function will run and numbers variable only contains numbers
                        else if (messageType == "T" && (n.IsDigitsOnly(number) == true))
                        {
                            Console.WriteLine("Tweet function will now run \n");
                            // run Tweet function 
                            Tweet();
                        }
                        else
                        {
                            // display error message if message id is incorrect
                            MessageBox.Show("Incorrect message header type entered, " +
                                "please enter a 10 character ID beginning with 'S', 'E' or 'T followed by 9 digits'.");
                        }
                    }
                    else
                    {
                        // display error message if message id is incorrect
                        MessageBox.Show("Invalid message header");
                    }
                }
            }
            catch (NullReferenceException)
            {
                string numberz = "s000000000,";
                System.IO.File.AppendAllText(@"messageIDs.txt", numberz);
            }
        }


        // SMS function will run and accept and mobile number and message body as well and transform an abbreviations into its full meaning.
        private void SMS()
        {
            numbers n = new numbers();
            // displays valid windoe to user with correct text boxes to enter information 
            SMSTweet();

            // sets labels 
            lbl__Sender.Content = "Mobile: ";
            lbl_Body.Content = "Text Message: ";

            // set max mobile length to 20
            txt_Sender.MaxLength = 20;

            string mobile = txt_Sender.Text;
            string body = txt_Body.Text;

            // if the mobile if only numbers will accept number
            if (n.IsDigitsOnly(mobile))
            {
                // if body is less or equal to 140 characters will accept message body
                if (body.Length <= 141)
                {
                    // as long as both mobile length and body length are greater than 0 that means enother field is empty
                    if (mobile.Length > 0 && body.Length > 0)
                    {
                        // body is sent to addAbbreviations method where any abbrevaitions found are transformed to full meaning
                        body = addAbbreviations(body);

                        // updated mesage body sent to user 
                        MessageBox.Show("Sender (Mobile): " + mobile + "\n" +
                                "Message Text: (Max 140 characters) " + body);

                        // message is ready to be writtem to JSON file
                        data stData = new data();
                        stData.ID = txt_Header.Text;
                        stData.Sender = mobile;
                        stData.Body = body;

                        Send(stData, null);

                        // once data has been written to JSON file data can be cleared allowing user to use anotehr function if they wish
                        Clear();
                        txt_Header.Clear();
                    }
                }
                else
                {
                    // if message body to long error message displayed
                    MessageBox.Show("Message Body is too long: " + body.Length + " characters");
                }
            }
            else
            {
                // if mobilke number incorect error message displayed
                MessageBox.Show("Incorrect mobile number entered");
            }
        }

        // Email function will run and accept a email address, subject, and message body as well and transform URL's.
        private void Email()
        {
            //set labels
            lbl__Sender.Content = "Email: ";
            lbl_Body.Content = "Email Message: ";

            // set max email address length to 60
            txt_Sender.MaxLength = 60;
            // set max email subject length to 20
            txt__Subject.MaxLength = 20;

            // display choise to user for either standard email or SIR email
            check_standard.Visibility = System.Windows.Visibility.Visible;
            check_SIR.Visibility = System.Windows.Visibility.Visible;

            // if the user pick SIR email then this will run
            if (check_SIR.IsChecked == true)
            {
                Console.WriteLine("Email SIR function will now run \n");
                // will display the nature of incidents selection panel to user
                list_NoI.Visibility = System.Windows.Visibility.Visible;

                // store email entered by user
                string email = txt_Sender.Text;
                // store subject entered by user
                string subject = txt__Subject.Text;
                // store body entered by user
                string body = txt_Body.Text;
                // store sort code entered by user
                string sortCode;
                // set Nature of Icident to blank
                string NoI = "";

                // allows user to choose a nature of incident from list
                try
                {
                    NoI = list_NoI.SelectedItem.ToString();
                    NoI = NoI.Replace(@"System.Windows.Controls.ListBoxItem: ", "");
                }
                catch (NullReferenceException)
                {
                    // if user does not choose a nature of icident then an error message will appear
                    MessageBox.Show("Error with Nature of Incident");
                }

                // check email and subject is in valid format
                if (email.Contains("@") && email.Contains(".") && subject.Length == 14)
                {
                    // check email is 1028 characters or less
                    if (body.Length <= 1029)
                    {
                        // send body to check if it conatins URL's
                        body = emailURL(body);
                        
                        // run sortCode Class to ensure sort code is correct
                        sortCodeClass sortClass = new sortCodeClass();
                        sortCode = sortClass.getSortCode(body);

                        // run code only if variables have information entered in them and are correct
                        if (email.Length > 0 && subject.Length > 0 && body.Length > 0 && sortCode.Length > 0 && NoI.Length > 0)
                        {
                            // display correct accpeted information to the user
                            MessageBox.Show("Sender (Email): " + email + "\n" + "Subject: " + subject + "\n" + "Sort Code: " + sortCode + "\n" +
                                "Nature of Incident: " + NoI + "\n" + "Message Text: (Max 1028 characters) " + body);

                            // send data to be written to JSON file
                            emailData eData = new emailData();
                            eData.ID = txt_Header.Text;
                            eData.Sender = email;
                            eData.Body = body;
                            eData.Subject = subject;
                            eData.NoI = NoI;
                            eData.SIR = true;

                            Send(null, eData);

                            // add sort code and nature of incident to SIR file this is to be used when using end session class to allow user to see SIR list
                            File.AppendAllText(@"SIR.txt", sortCode + " " + NoI + ",");

                            // clear data fields to allow user to enter a new massgae type
                            Clear();
                            txt_Header.Clear();
                        }
                        else
                        {
                            // display to user if error in message body
                            MessageBox.Show("Error in message- potential field is empty");
                        }
                    }
                    else
                    {
                        //display error message if user enters incorrect sort code
                        MessageBox.Show("Error in Message Body- potential sort code is incorrect");
                    }
                }
                else
                {
                    //display error message if user enters incorrect email address
                    MessageBox.Show("Incorrect email entered");
                }

            }
            // if the user pick SIR email then this will run
            else if (check_standard.IsChecked == true)
            {
                // set max email address length to 60
                txt_Sender.MaxLength = 60;
                // set max email subject length to 20
                txt__Subject.MaxLength = 20;

                // store email entered by user
                string email = txt_Sender.Text;
                // store subject entered by user
                string subject = txt__Subject.Text;
                // store body entered by user
                string body = txt_Body.Text;

                // check email and subject is in valid format
                if (email.Contains("@") && email.Contains(".") && subject.Length <= 20)
                {
                    // check email is 1028 characters or less
                    if (body.Length <= 1029)
                    {
                        // send body to check if it conatins URL's
                        body = emailURL(body);

                        // run code only if variables have information entered in them and are correct
                        if (email.Length > 0 && subject.Length > 0 && body.Length > 0)
                        {
                            // display correct accpeted information to the user
                            MessageBox.Show("Sender (Email): " + email + "\n" + "Subject: " + subject +
                            "Message Text: (Max 1028 characters) " + body);

                            // send data to be written to JSON file
                            emailData eData = new emailData();
                            eData.ID = txt_Header.Text;
                            eData.Sender = email;
                            eData.Body = body;
                            eData.Subject = subject;
                            eData.SIR = false;

                            Send(null, eData);

                            // clear data fields to allow user to enter a new massgae type
                            Clear();
                            txt_Header.Clear();
                        }
                    }
                    else
                    {
                        // display to user if error in message body
                        MessageBox.Show("Message Body is too long: " + body.Length + " characters");
                    }
                }
                else
                {
                    //display error message if user enters incorrect email address
                    MessageBox.Show("Incorrect email entered");
                }
            }
        }

        // Tweet function will run and accept a Twitter ID and message body as well and transform any abbreviations into its full meaning and add hashtags and mentions to a trending list.

        private void Tweet()
        {
            // displays valid windoe to user with correct text boxes to enter information 
            SMSTweet();

            // set labels
            lbl__Sender.Content = "Twitter ID: ";
            lbl_Body.Content = "Tweet Message: ";

            // set max twitter ID length to 16
            txt_Sender.MaxLength = 16;

            // store user entered twitter ID
            string twitterID = txt_Sender.Text;
            // store user entered message body
            string body = txt_Body.Text;

            // run if tweitter id contains '@' and twitter length is less than or equal to 15 characters
            if (twitterID.Contains("@") && twitterID.Length <= 15)
            {
                // run if titter messsage body is 140 or less characters
                if (body.Length <= 141)
                {
                    // check for abbrevaitions and transform into full meaning
                    body = addAbbreviations(body);
                    // send body to addHashtags method to create trending and mentions list for end session
                    addHashtags(body);

                    // if id and body are not empty
                    if (twitterID.Length > 0 && body.Length > 0)
                    {
                        // display correct information to user
                        MessageBox.Show("Sender: Twitter ID (max 15 characters): " + twitterID + "\n" +
                            "Message Text: (Max 140 characters) " + body);

                        // send data to be written to JSON file
                        data stData = new data();
                        stData.ID = txt_Header.Text;
                        stData.Sender = twitterID;
                        stData.Body = body;

                        Send(stData, null);

                        // clear data so user can write new mesaage
                        Clear();
                        txt_Header.Clear();
                    }
                }
                else
                {
                    // display error message if message body too long
                    MessageBox.Show("Message body is too long" + body.Length);
                }
            }
            else
            {
                // display to user if twitter id does not contain '@' and is greater than 15 characters
                MessageBox.Show("Twitter ID must contain '@' followed by 15 characters");
            }
        }

        // used for SMS and Tweet classes so that the abbrevations can be turned into the full meaning
        public string addAbbreviations(string stringBody)
        {
            // dictionary storing the abbreviations and full meanings
            Dictionary<string, string> dictionary = new Dictionary<string, string>();

            // reads in abbreviationd file
            var reader = new StreamReader("textwords.csv");

            using (reader)
            {
                while ((!reader.EndOfStream))
                {
                    string abb = reader.ReadLine().ToString();
                    string shortAbb = abb.Substring(0, abb.IndexOf(','));
                    string longAbb = abb.Substring(abb.IndexOf(',') + 1);
                    // adds abbrevaitions and meaning to dictionary
                    dictionary.Add(shortAbb, longAbb);
                }
            }

            // split message body into words
            var words = stringBody.Split().Select(x => x.Trim());

            // checks dictionary for the words and if it finds it will replace the abbreviation with the abbreviation and the full meaning 
            foreach (KeyValuePair<string, string> abb in dictionary)
            {
                foreach (var item in words)
                {
                    // if the word has a hashtag or at symbol must not transorm that
                    if (!item.Contains("@") && !item.Contains("#"))
                    {
                        if (abb.Key == item)
                        {
                            // add full meaning in a pair of arrows heads
                            string replacement = item + "<" + abb.Value + ">";
                            string newText = stringBody.Replace(item, replacement);
                            
                            // set string body to the new text found
                            stringBody = newText;
                        }
                    }
                }
            }
            // send new text full meaning back to user
            return stringBody;
        }

        // add hashtags this method is used to find hashtags in the tweet message body and store them into lists 
        public string addHashtags(string stringBody)
        {
            // store trending hashtags
            List<string> trending = new List<string>();
            // store mentions list
            List<string> mentions = new List<string>();

            // split message body into words
            var words = stringBody.Split().Select(x => x.Trim());


            foreach (var item in words)
            {
                // if word conatins hashtag add to trending list
                if (item.Contains("#"))
                {
                    trending.Add(item + " ");
                }
                // if word conatins at symbol add to mentions list
                if (item.Contains("@"))
                {
                    mentions.Add(item + " ");
                }
            }

            // write trending list to a file
            foreach (string h in trending)
            {
                File.AppendAllText(@"Hashtags.txt", h);
            }

            // write mentions list to a file
            foreach (string t in mentions)
            {
                File.AppendAllText(@"Trending.txt", t);
            }

            return stringBody;
        }

        // this class check if the sort code entered is correct
        public class sortCodeClass
        {
            public string getSortCode(string sortCode)
            {
                // read in message body
                string sCode = null;

                // find sort code by splitting body into words
                var words = sortCode.Split().Select(x => x.Trim());

                // if word contains '-' then will know its a sort code
                foreach (var item in words)
                {
                    if (item.Contains("-"))
                    {
                        // set sCode to item conatining '-'
                        sCode = item;
                    }
                }
                // if scode is not empty then run this
                if (sCode != null)
                {
                    string holdSortCode = sCode;
                    // replace '-' with nothing
                    sCode = sCode.Replace(@"-", "");

                    // check the sort code is only numbers 
                    numbers n = new numbers();
                    if (n.IsDigitsOnly(sCode) == true)
                    {
                        // if it is then sort code is correct return the valid sortcode
                        sCode = holdSortCode;
                    }
                    else if (n.IsDigitsOnly(sCode) == false)
                    {
                        // if it is not then return blank
                        sCode = "";
                    }
                    // set sort code to scode
                    sortCode = sCode;
                }
                // return new sort code 
                return sortCode;
            }
        }

        // this class is to run when the user presses end session meaning they are done using the program and
        // now want to see the trending list, mentions list and the SIR list
        public class showTheEnd
        {
            public void showEnd()
            {
                // opens new window
                Window1 w1 = new Window1();

                // list of mentions 
                List<string> mentions = new List<string>();
                string[] ment = null;

                // reads in mentions file created earlier
                var readerMent = new StreamReader(@"Trending.txt");

                using (readerMent)
                {
                    while ((!readerMent.EndOfStream))
                    {
                        // add mentions to mentions list
                        string mentionWord = readerMent.ReadLine().ToString();
                        mentions.Add(mentionWord);
                    }
                }

                // split mentions by space and add to array
                foreach (String st in mentions)
                {
                    ment = st.Split(' ');
                }

                // count reoccurance of mentions and reorder list to show most mentions at top of list
                var q = from x in ment
                        group x by x into g
                        let count = g.Count()
                        orderby count descending
                        select new { Value = g.Key, Count = count };

                // display mentions list to user
                foreach (var x in q)
                {
                    if (x.Value.Length > 0)
                    {
                        Console.WriteLine("Value: " + x.Value + " Count: " + x.Count);
                        w1.txt_Mentions.Text += (x.Value + " " + x.Count + "\n");
                    }
                }

                // list of trending hashtags
                List<string> trending = new List<string>();
                string[] trend = null;

                // reads in trending file created earlier
                var readerTrend = new StreamReader(@"Hashtags.txt");

                using (readerTrend)
                {
                    while ((!readerTrend.EndOfStream))
                    {
                        // add trending hashtags to trending list
                        string trendingWord = readerTrend.ReadLine().ToString();
                        trending.Add(trendingWord);
                    }
                }

                // split trending by space and add to array
                foreach (String st in trending)
                {
                    trend = st.Split(' ');

                }

                // count reoccurance of trending hashtags and reorder list to show most trending hashtags at top of list
                var b = from x in trend
                        group x by x into g
                        let count = g.Count()
                        orderby count descending
                        select new { Value = g.Key, Count = count };

                // display trending list to user
                foreach (var x in b)
                {
                    if (x.Value.Length > 0)
                    {
                        Console.WriteLine("Value: " + x.Value + " Count: " + x.Count);
                        w1.txt_Trending.Text += (x.Value + " " + x.Count + "\n");
                    }
                }

                // list of Significant Incident Report sort code and nature of incidents
                List<string> SIRList = new List<string>();
                string[] sir = null;

                // reads in SIR file created earlier
                var readerSIR = new StreamReader(@"SIR.txt");

                using (readerSIR)
                {
                    while ((!readerSIR.EndOfStream))
                    {
                        // add SIR to SIR list
                        string sirWord = readerSIR.ReadLine().ToString();
                        SIRList.Add(sirWord);
                    }
                }

                // split SIR by comma and add to array
                foreach (String st in SIRList)
                {
                    sir = st.Split(',');
                }

                // display sir list to user
                foreach (String s in sir)
                {
                    Console.WriteLine(s);
                    w1.txt_SIR.Text += (s + "\n");
                }

                // display end session informaiton in new window to user 
                w1.Show();
            }
        }

        // check if email body contains URL and remove
        public string emailURL(string stringBody)
        {
            // store emmail URL
            List<string> email = new List<string>();

            // split email body into words
            var words = stringBody.Split().Select(x => x.Trim());

            // for each word if it contain the https:// then we know it is a url and it should be added to the email list
            foreach (var emailItem in words)
            {

                Uri uriResult;
                // sends word to url method to check if it is a valid url
                bool result = ValidHttpURL(emailItem, out uriResult);

                // once valid url is found then the URL will be removed and replaced by < URL Quarantined >
                if (result == true)
                {
                    email.Add(uriResult?.AbsoluteUri);
                    Console.WriteLine(result + "\t" + uriResult?.AbsoluteUri);

                    string emailReplacement = "< URL Quarantined >";
                    string newTexts = stringBody.Replace(emailItem, emailReplacement);
                    stringBody = newTexts;
                }
            }
            // return new email message body without urls
            return stringBody;
        }

        // this method is used to validate a URL 
        public static bool ValidHttpURL(string s, out Uri resultURI)
        {
            if (Uri.TryCreate(s, UriKind.Absolute, out resultURI))
                return (resultURI.Scheme == Uri.UriSchemeHttp ||
                        resultURI.Scheme == Uri.UriSchemeHttps);

            return false;
        }

        // this class is used to validate a string to ensure only numbers have been entered
        public class numbers
        {
            public bool IsDigitsOnly(string stringEntered)
            {
                foreach (char check in stringEntered)
                {
                    if (check < '0' || check > '9')
                        // if string is not 0 1 2 3 4 5 6 7 8 9 then return false
                        return false;
                }
                // if string is between 0-9 then return true
                return true;
            }
        }

       // if standard email is selected will display the standard email text boxes and disable SIR email button
        private void check_standard_Checked(object sender, RoutedEventArgs e)
        {
            check_SIR.IsEnabled = false;
            // display standard email data boxes
            EmailVisible();
        }

        // if SIR email is selected will display the SIR email text / selection boxes and disable standard email button
        private void check_SIR_Checked(object sender, RoutedEventArgs e)
        {
            check_standard.IsEnabled = false;
            // display SIR email data boxes
            list_NoI.Visibility = System.Windows.Visibility.Visible;
            EmailVisible();
            // set subject to SIR with todays date 
            txt__Subject.Text = "SIR " + DateTime.Now.Date.ToShortDateString();
            // set text body first line to allow user to enter sort code
            txt_Body.Text = "Sort Code: nn-nn-nn\n";
        }

        // if the user changes the ID text box then clear all the fields
        private void txt_Header_TextChanged(object sender, TextChangedEventArgs e)
        {
            Clear();
            check_SIR.IsChecked = false;
            check_standard.IsChecked = false;
        }

        // used to parse the tweet and SMS class data so that it can be written to JSON
        private class data
        {
            public string ID { get; set; }

            public string Body { get; set; }

            public string Sender { get; set; }

        }

        // used to parse the email class data so that it can be written to JSON
        private class emailData
        {
            public string ID { get; set; }

            public string Body { get; set; }

            public string Subject { get; set; }

            public string Sender { get; set; }

            public string NoI { get; set; }

            public Boolean SIR { get; set; }
        }

        // this function will write the valid SMS, Email and Tweet data to a JSON file 
        private void Send(data stData, emailData ha)
        {
            string messageID = txt_Header.Text.ToUpper();
            string messageType = txt_Header.Text.Substring(0, 1).ToUpper();
            
            if (messageType == "S" || messageType == "T")
            {
                var filePath = @"stTestHA.json";
                var jsonData = File.ReadAllText(filePath);
                var tweetList = JsonConvert.DeserializeObject<List<data>>(jsonData) ?? new List<data>();

                // get data from sms or tweet class
                tweetList.Add(new data()
                {
                    ID = stData.ID,
                    Body = stData.Body,
                    Sender = stData.Sender
                });

                // serialize data into JSON
                string json = JsonConvert.SerializeObject(tweetList);

                // write sms and tweet data to JSON file
                System.IO.File.WriteAllText(@"stTestHA.json", json);

                // writes message ID's to seperate file to ensure they cannot be used twice
                File.AppendAllText(@"messageIDs.txt", messageID + ",");
            }
            ////////////////////////////////////////////////////////////////////////////////////////////
            else if (messageType == "E")
            {
                var emailFilePath = @"emailTestHA.json";
                var emailJsonData = File.ReadAllText(emailFilePath);
                var emailList = JsonConvert.DeserializeObject<List<emailData>>(emailJsonData) ?? new List<emailData>();

                // get data from email class
                emailList.Add(new emailData()
                {
                    ID = ha.ID,
                    Body = ha.Body,
                    Subject = ha.Subject,
                    Sender = ha.Sender,
                    NoI = ha.NoI,
                    SIR = ha.SIR
                });

                // serialize email data into JSON
                string emailJson = JsonConvert.SerializeObject(emailList);

                // write email data to JSON file
                System.IO.File.WriteAllText(@"emailTestHA.json", emailJson);

                // writes message ID's to seperate file to ensure they cannot be used twice
                File.AppendAllText(@"messageIDs.txt", messageID + ",");
            }
            else
            {
                Console.WriteLine("Send - Incorrect message header entered, please re-try \n");
            }
        }

        // this function runs when the user clicks end button so will run 
        // class thich displays to the user trending list, mentions list and sir list
        private void btn_end_Click(object sender, RoutedEventArgs e)
        {
            // diplays new window with end session information until user closes it
            showTheEnd SE = new showTheEnd();
            SE.showEnd();

            //closes main window to show that the session has ended and no more messages can be written unless progrma is run again
            Close();
        }

        // clears the text boxes if user clicks clear
        private void btn_Clear_Click(object sender, RoutedEventArgs e)
        {
            txt_Header.Clear();
            txt_Body.Clear();
            txt_Sender.Clear();
            txt__Subject.Clear();
        }

        // clear method removes text boxes from screen
        // used when a particular message has been successfully finished or user changes message ID
        private void Clear()
        {
            txt_Body.Clear();
            txt_Sender.Clear();
            txt__Subject.Clear();

            lbl__Sender.Visibility = System.Windows.Visibility.Hidden;
            txt_Sender.Visibility = System.Windows.Visibility.Hidden;

            lbl__Subject.Visibility = System.Windows.Visibility.Hidden;
            txt__Subject.Visibility = System.Windows.Visibility.Hidden;

            txt_Body.Visibility = System.Windows.Visibility.Hidden;
            lbl_Body.Visibility = System.Windows.Visibility.Hidden;

            check_standard.Visibility = System.Windows.Visibility.Hidden;
            check_SIR.Visibility = System.Windows.Visibility.Hidden;
            list_NoI.Visibility = System.Windows.Visibility.Hidden;
        }

        // displays valid text boxes for sms and tweet classes
        private void SMSTweet()
        {
            lbl__Sender.Visibility = System.Windows.Visibility.Visible;
            txt_Sender.Visibility = System.Windows.Visibility.Visible;

            lbl__Subject.Visibility = System.Windows.Visibility.Hidden;
            txt__Subject.Visibility = System.Windows.Visibility.Hidden;

            txt_Body.Visibility = System.Windows.Visibility.Visible;
            lbl_Body.Visibility = System.Windows.Visibility.Visible;

            check_standard.Visibility = System.Windows.Visibility.Hidden;
            check_SIR.Visibility = System.Windows.Visibility.Hidden;

            list_NoI.Visibility = System.Windows.Visibility.Hidden;

        }

        // displays valid text boxes for email classes
        private void EmailVisible()
        {
            lbl__Sender.Visibility = System.Windows.Visibility.Visible;
            txt_Sender.Visibility = System.Windows.Visibility.Visible;

            lbl__Subject.Visibility = System.Windows.Visibility.Visible;
            txt__Subject.Visibility = System.Windows.Visibility.Visible;

            txt_Body.Visibility = System.Windows.Visibility.Visible;
            lbl_Body.Visibility = System.Windows.Visibility.Visible;
        }

        // displays valid text boxes for when SIR email check box is unselected
        private void check_SIR_Unchecked(object sender, RoutedEventArgs e)
        {
            check_standard.IsEnabled = true;

            txt_Body.Clear();
            txt_Sender.Clear();
            txt__Subject.Clear();

            lbl__Sender.Visibility = System.Windows.Visibility.Hidden;
            txt_Sender.Visibility = System.Windows.Visibility.Hidden;

            lbl__Subject.Visibility = System.Windows.Visibility.Hidden;
            txt__Subject.Visibility = System.Windows.Visibility.Hidden;

            txt_Body.Visibility = System.Windows.Visibility.Hidden;
            lbl_Body.Visibility = System.Windows.Visibility.Hidden;
            list_NoI.Visibility = System.Windows.Visibility.Hidden;
        }

        // displays valid text boxes for when standard email check box is unselected
        private void check_standard_Unchecked(object sender, RoutedEventArgs e)
        {
            check_SIR.IsEnabled = true;

            txt_Body.Clear();
            txt_Sender.Clear();
            txt__Subject.Clear();

            lbl__Sender.Visibility = System.Windows.Visibility.Hidden;
            txt_Sender.Visibility = System.Windows.Visibility.Hidden;

            lbl__Subject.Visibility = System.Windows.Visibility.Hidden;
            txt__Subject.Visibility = System.Windows.Visibility.Hidden;

            txt_Body.Visibility = System.Windows.Visibility.Hidden;
            lbl_Body.Visibility = System.Windows.Visibility.Hidden;
        }


        private void Btn_Read_Click(object sender, RoutedEventArgs e)
        {
            Window2 w2 = new Window2();

            w2.Show();

        }
    }
}
