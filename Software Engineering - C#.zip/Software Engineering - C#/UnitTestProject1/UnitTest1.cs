﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CourseworkHA.UnitTests
{
    [TestClass]
    public class UnitTests
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
