﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CourseworkHA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseworkHA.Tests
{
    [TestClass()]
    public class MainWindowTests
    {
        [TestMethod()]
        public void getSortCodeTest()
        {
            string sortCode = "12-34-56";

            var sort = new CourseworkHA.MainWindow().getSortCode(sortCode);

            Assert.Fail();
        }
    }
}