﻿using CourseworkHA;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace CourseworkHA.Tests
{
    [TestClass()]
    public class UnitTest1
    {
        [TestMethod()]
        public void SortCodeValid()
        {
            string check = "12-34-56";
            string expectedResult = "12-34-56";

            MainWindow.sortCodeClass ha = new MainWindow.sortCodeClass();

            string actualResult = ha.getSortCode(check);

            Assert.IsTrue(actualResult == expectedResult);
        }

        [TestMethod()]
        public void SortCodeInvalid()
        {
            string check = "12-AB-9K";
            string expectedResult = "";

            MainWindow.sortCodeClass ha = new MainWindow.sortCodeClass();

            string actualResult = ha.getSortCode(check);

            Assert.AreEqual(actualResult, expectedResult);
        }


        [TestMethod()]
            public void MobileCorrect()
            {
                string mobile = "07678457553";
                bool expectedResult = true;

                MainWindow.numbers ha = new MainWindow.numbers();

                bool actualResult = ha.IsDigitsOnly(mobile);

                Assert.AreEqual(actualResult, expectedResult);
            }

            [TestMethod()]
            public void MobileIncorrect()
            {
                string mobile = "ABCDEFGHIJ";
                bool expectedResult = false;

                MainWindow.numbers ha = new MainWindow.numbers();

                bool actualResult = ha.IsDigitsOnly(mobile);

                Assert.AreEqual(actualResult, expectedResult);
            }

    }
}